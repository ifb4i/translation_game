# Import
import deepl
from pathlib import Path
from time import perf_counter
from datetime import datetime


# https://pypi.org/project/deepl/
# https://developers.deepl.com/docs
# https://developers.deepl.com/docs/api-reference/translate/openapi-spec-for-text-translation
# https://developers.deepl.com/docs/api-reference/translate#request-body-descriptions
# ===;
MY_ENCODING = 'utf-8'
TAG_HANDLING = 'html'
# ===;
INPUT_NAME = '01_Input.txt'
OUTPUT_EXTENSION = 'html'
# Website tool is working with both, source language and target language.
# https://developers.deepl.com/docs/resources/supported-languages
SOURCE_LANG = 'sk'
TARGET_LANG = 'de'
# Formality -> Options: default/more/less/prefer_more/prefer_less
FORMALITY = 'default'
IGNORE_TAGS_LIST = ['img', 'table']
# '' / 'name'...
GLOSSARY_ID = ''
# e.g.: 'This is context.'
CONTEXT = ''
# ===;

def calculate_elapsed_time(start: str, end: str) -> str:
    time = int(end) - int(start)
    return (f'Execution time: {time} second(s)...')

def get_time_stamp() -> str:
    stamp = str(datetime.now()).replace(":", "").split(".")[0].replace(" ","").replace("-","")
    return stamp

class TranslateFields:
    def __init__(self,
                 my_encoding: str,
                 output_extension: str,
                 source_lang: str,
                 target_lang: str,
                 formality: str,
                 glossary_id: str,
                 context: str,
                 tag_handling: str,
                 ignore_tags_list: list,
                 ) -> None:
        self.my_encoding = my_encoding
        self.source_lang = source_lang
        self.target_lang = target_lang
        self.output_extension = output_extension
        self.formality = formality
        self.glossary_id = glossary_id
        self.context = context
        self.tag_handling = tag_handling
        self.ignore_tags_list = ignore_tags_list
        self._cwd = Path.cwd()
        self._deepl_auth_key = self._get_deepl_auth_key()

    def set(self, file_name: str) -> str:
        with open(f'{self._cwd}\\01_Input\\{file_name}', 'r', encoding=self.my_encoding) as f:
            my_field = f.read().strip()

            f.close()

        return my_field

    def get(self, my_field: str) -> None:
        with open(f'{self._cwd}\\99_Output\\99_Output_{self.target_lang.upper()}_{get_time_stamp()}.{self.output_extension}', 'w', encoding=MY_ENCODING) as f:
            f.write(my_field)

            f.close()

    def _get_deepl_auth_key(self) -> str:
        with open(f'{self._cwd}\\assets\\_AuthKey.txt', 'r') as f:
            deepl_auth_key = f.read().strip()
            
            f.close()
        
        return deepl_auth_key

    def translate_with_deepl(self, text: str) -> str:
        translator = deepl.Translator(self._deepl_auth_key)

        return str(translator.translate_text(
            text,
            source_lang=self.source_lang,
            target_lang=self.target_lang,
            formality=self.formality,
            glossary=self.glossary_id,
            context=self.context,
            tag_handling=self.tag_handling,
            ignore_tags=self.ignore_tags_list,
        ))

# ===;
def main() -> None:
    TimeStart = perf_counter()

    translation = TranslateFields(
        MY_ENCODING,
        OUTPUT_EXTENSION,
        SOURCE_LANG,
        TARGET_LANG,
        FORMALITY,
        GLOSSARY_ID,
        CONTEXT,
        TAG_HANDLING,
        IGNORE_TAGS_LIST,
    )

    my_input = translation.set(INPUT_NAME)
    # print(my_input)
    my_translation = translation.translate_with_deepl(my_input)
    # print(my_translation)
    translation.get(my_translation)

    TimeEnd = perf_counter()
    print(calculate_elapsed_time(TimeStart, TimeEnd))

    # print('Probably done... Press any key...')
    input('Probably done... Press any key...')

if __name__ == '__main__':
    main()
