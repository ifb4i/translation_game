import deepl
from pathlib import Path


# https://developers.deepl.com/docs/api-reference/glossaries
# https://developers.deepl.com/docs/api-reference/glossaries/openapi-spec-for-glossary-management
GLOSSARY_NAME = "My glossary"
SOURCE_LANG = "EN"
TARGET_LANG = "DE"
GLOSSARY_ENTRIES = {
    "artist": "Maler",
    "prize": "Gewinn",
}

class DeeplGlossary:
    def __init__(self) -> None:
        self._cwd = Path.cwd()
        self._translator = deepl.Translator(self._get_deepl_auth_key())

    def create_glossary(self) -> None:
        # Create an English to German glossary with two terms:
        entries = GLOSSARY_ENTRIES
        my_glossary = self._translator.create_glossary(
            GLOSSARY_NAME,
            source_lang=SOURCE_LANG,
            target_lang=TARGET_LANG,
            entries=entries,
        )
        self._append_my_glossary(my_glossary.glossary_id)
        print(
            f"Created '{my_glossary.name}' ({my_glossary.glossary_id}) "
            f"{my_glossary.source_lang}->{my_glossary.target_lang} "
            f"containing {my_glossary.entry_count} entries"
        )
        # Example: Created 'My glossary' (559192ed-8e23-...) EN->DE containing 2 entries

    def get_glossary(self, glossary_id: str) -> None:
        # Retrieve a stored glossary using the ID
        # glossary_id = "559192ed-8e23-..."
        my_glossary = self._translator.get_glossary(glossary_id)
        # ...
        # TBD;
        print(my_glossary)

    def list_glossaries(self) -> list:
        glossaries = self._translator.list_glossaries()
        return glossaries

    def delete_glossary(self, glossary_id: str) -> None:
        self._translator.delete_glossary(glossary_id)

    def _get_deepl_auth_key(self) -> str:
        with open(f'{self._cwd}\\assets\\_AuthKey.txt', 'r') as f:
            deepl_auth_key = f.read().strip()
            
            f.close()
        
        return deepl_auth_key

    def _append_my_glossary(self, glossary_id) -> None:
        with open(f'{self._cwd}\\99_Output\\my_glossaries.txt', 'a') as f:
            f.write(f'{glossary_id}\n')

            f.close()


def main() -> None:

    glossary = DeeplGlossary()
    glossary.create_glossary()

    # my_list = glossary.list_glossaries()
    # print(f'Before: {my_list}')
    # for item in my_list:
    #     glossary.delete_glossary(item)
    # print(f'After: {my_list}')

    # print('Probably done... Press any key...')
    input('Probably done... Press any key...')


if __name__ == '__main__':
    main()
